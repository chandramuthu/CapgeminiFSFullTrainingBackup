package com.cg.pagemodel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BookingPage {

	public BookingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement firstName;
	
	public void setFirstName(String name) {
		firstName.sendKeys(name);
	}
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lastName;

	public void setLastName(String name) {
		lastName.sendKeys(name);
	}
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement email;
	public void setEmail(String mail) {
		email.sendKeys(mail);
	}
	@FindBy(name="Phone")
	@CacheLookup
	WebElement mobileno;
	public void setMobileNo(String no) {
		mobileno.sendKeys(no);
	}
	@FindBy(tagName="textarea")
	@CacheLookup
	WebElement addres;
	public void setAddress(String add) {
addres.sendKeys(add);	
	}
	@FindBy(name="city")
	@CacheLookup
	Select city;
	public void selectCity(int index) {
		city.selectByIndex(index);
	}
	@FindBy(name="state")
	@CacheLookup
	Select state;
	
	public void selectState(int index) {
		state.selectByIndex(index);
	}
	@FindBy(name="persons")
	@CacheLookup
	WebElement person;
	public void setPersonCount(String num) {
		person.sendKeys(num);
	}
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardName;
	public void setCardHolderName(String name) {
		cardName.sendKeys(name);
	}
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement cardnubmer;
	public void setCardNumber(String number) {
		cardName.sendKeys(number);
	}
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement cvv;

	public void setCvv(String no) {
		cvv.sendKeys(no);
	}
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement month;
	public void setMonth(String mon) {
		month.sendKeys(mon);
	}
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement year;
	public void setYear(String yr) {
		year.sendKeys(yr);
	}
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement button;
public void clickButton() {
	button.click();
}
}
