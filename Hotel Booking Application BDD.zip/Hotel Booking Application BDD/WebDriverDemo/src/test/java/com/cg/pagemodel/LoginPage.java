package com.cg.pagemodel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	@FindBy(name="userName")
	@CacheLookup
	private WebElement userName;
	
	@FindBy(id="pwd1")
	@CacheLookup
	private WebElement pwd;
	@FindBy(className="btn")
	private WebElement loginBtn;
	
	@FindBy(id="userErrMsg")
	@CacheLookup
	private WebElement userError;
	
	@FindBy(id="pwdErrMsg")
	@CacheLookup
	private WebElement pwdError;

	public void setUserName(String name) {
		userName.sendKeys(name);
	}
	public void setPwd(String  pwd) {
		this.pwd.sendKeys(pwd);
	}
	public void ClickLoginBtn() {
		this.loginBtn.click();
	}
	public String getUserError() {
		return userError.getText();
	}
	public String getPwdError() {
		return pwdError.getText();
	}

		
	
	
}
