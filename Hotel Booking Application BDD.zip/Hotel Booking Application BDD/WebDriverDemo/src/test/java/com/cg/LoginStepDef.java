package com.cg;

import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagemodel.LoginPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class LoginStepDef {
	
	WebDriver driver;
	LoginPage loginpage;
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Backup\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
		loginpage= new LoginPage(driver);
	}
	@Given("^customer is on login page$")
	public void customer_is_on_login_page() throws Throwable {
		driver.get("D:\\Backup\\hotelBooking\\login.html");
	}
	@Then("^heading should be present on the page$")
	public void heading_should_be_present_on_the_page() throws Throwable {
	   String heading ="Hotel Booking Application";
	   WebElement divEle= driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1"));
	String actualHeading= divEle.getText();
		assertEquals(heading, actualHeading);
	}

	@When("^customer enters correct username and password and click on login button$")
	public void customer_enters_correct_username_and_password_and_click_on_login_button() throws Throwable {
		loginpage.setUserName("capgemini");
		loginpage.setPwd("capg1234");
		loginpage.ClickLoginBtn();
	}
	@Then("^Home page should be displayed$")
	public void home_page_should_be_displayed() throws Throwable {
	String expText="Hotel Booking Form";
	String pageSource= driver.getPageSource();
	assertTrue(pageSource.contains(expText));
	driver.close();
	}
	@When("^customer enters invalid username and password and click on login button$")
	public void customer_enters_invalid_username_and_password_and_click_on_login_button() throws Throwable {
	loginpage.setUserName("Tertrrt");
	loginpage.setPwd("rrrtretert");
	loginpage.ClickLoginBtn();
	}
	@Then("^Error Message should be displayed$")
	public void error_Message_should_be_displayed() throws Throwable {
	 String expErrorMessage="Invalid username or password ";
	 String actualMessage=driver.switchTo().alert().getText();
	 assertEquals(actualMessage, expErrorMessage);
	}
	@When("^customer enters blank username and password and click on login button$")
	public void customer_enters_blank_username_and_password_and_click_on_login_button() throws Throwable {
		loginpage.ClickLoginBtn();
	}

	@Then("^Error Message should be displayed for username field$")
	public void error_Message_should_be_displayed_for_username_field() throws Throwable {
	   String expError= "*Please enter userName";
	   String actualError= loginpage.getUserError();
	   assertEquals(actualError, expError);
	}

	@When("^customer enters username and blank password and click on login button$")
	public void customer_enters_username_and_blank_password_and_click_on_login_button() throws Throwable {
		loginpage.setUserName("capgemini");
		loginpage.ClickLoginBtn();
	}

	@Then("^Error Message should be displayed for password field$")
	public void error_Message_should_be_displayed_for_password_field() throws Throwable {
		   String expError= "* Please enter password.";
		  String actualError=loginpage.getPwdError();
		   assertEquals(actualError, expError);
		}
}
