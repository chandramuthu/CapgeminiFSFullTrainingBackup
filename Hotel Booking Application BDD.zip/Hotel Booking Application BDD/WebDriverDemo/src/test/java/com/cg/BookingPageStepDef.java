package com.cg;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.cg.pagemodel.BookingPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookingPageStepDef {


	WebDriver driver;
	BookingPage bookingpage;
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"E:\\Driver");
		driver= new ChromeDriver();
		bookingpage= new BookingPage(driver);
	}
	@Given("^customer is on hotelbooking page$")
	public void customer_is_on_hotelbooking_page() throws Throwable {
		driver.get("D:\\Backup\\hotelBooking\\hotelBooking.html");
		
	}

	@When("^customer enters all correct data and clicks confirm booking button$")
	public void customer_enters_all_correct_data_and_clicks_confirm_booking_button() throws Throwable {
		bookingpage.selectCity(2);
		bookingpage.selectState(3);
		bookingpage.setFirstName("Yogini");
		bookingpage.setLastName("Naik");
		bookingpage.setAddress("Pune");
		bookingpage.setCardNumber("436547");
		bookingpage.setCardHolderName("Eewreret");
		bookingpage.setEmail("yogiin@gmail.com");
		bookingpage.setMonth("11");
		bookingpage.setYear("2017");
		bookingpage.setCvv("534");
		bookingpage.setPersonCount("4");
		bookingpage.clickButton();
	}

	@Then("^application moves to Success page$")
	public void application_moves_to_Success_page() throws Throwable {
	   String pagesource= driver.getPageSource();
	   assertTrue(pagesource.contains("Booking Completed"));
	}

	@When("^customer clicks on confirm booknig button without entering firstname$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_firstname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	bookingpage.clickButton();
	}

	@Then("^error message for username field should be displayed$")
	public void error_message_for_username_field_should_be_displayed() throws Throwable {
String exp= "Please fill the First Name";
String actual= driver.switchTo().alert().getText();
assertEquals(actual, exp);
		}

	@When("^customer clicks on confirm booknig button without entering lastname$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_lastname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bookingpage.setFirstName("Iftyry");
		bookingpage.clickButton();
	}

	@Then("^error message for lastname field should be displayed$")
	public void error_message_for_lastname_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String exp= "Please fill the Last Name";
		String actual= driver.switchTo().alert().getText();
		assertEquals(actual, exp);
	}
	

	@When("^customer clicks on confirm booknig button without entering email$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		bookingpage.setFirstName("rtereter");
		bookingpage.setLastName("ertretr");
		bookingpage.clickButton();
	}

	@Then("^error message for email field should be displayed$")
	public void error_message_for_email_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String exp="Please fill the Emai";
		String actual=driver.switchTo().alert().getText();
		assertEquals(actual, exp);
		driver.close();
	}

	@When("^customer clicks on confirm booknig button without entering mobileno$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_mobileno() throws Throwable {
		bookingpage.setFirstName("rtereter");
		bookingpage.setLastName("ertretr");
		bookingpage.setEmail("yogini@gmail.com");
		bookingpage.clickButton();
	}

	@Then("^error message for mobileNo field should be displayed$")
	public void error_message_for_mobileNo_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without entering valid mobile no$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_valid_mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^error message for valid mobileno field should be displayed$")
	public void error_message_for_valid_mobileno_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without entering address$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^error message for address field should be displayed$")
	public void error_message_for_address_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without selecting city$")
	public void customer_clicks_on_confirm_booknig_button_without_selecting_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^error message for city field should be displayed$")
	public void error_message_for_city_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without selecting state$")
	public void customer_clicks_on_confirm_booknig_button_without_selecting_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^error message for state field should be displayed$")
	public void error_message_for_state_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without selecting guest count$")
	public void customer_clicks_on_confirm_booknig_button_without_selecting_guest_count() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}
	@Then("^error message for guest count  field should be displayed$")
	public void error_message_for_guest_count_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without entering cardholder name$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_cardholder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^error message for cardholder name  field should be displayed$")
	public void error_message_for_cardholder_name_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without entering cardnumber$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_cardnumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^error message for cardnumber field should be displayed$")
	public void error_message_for_cardnumber_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without entering cvv$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_cvv() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^error message for cvv field should be displayed$")
	public void error_message_for_cvv_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without entering emp month$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_emp_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^error message for month  field should be displayed$")
	public void error_message_for_month_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^customer clicks on confirm booknig button without entering year$")
	public void customer_clicks_on_confirm_booknig_button_without_entering_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^error message for year  field should be displayed$")
	public void error_message_for_year_field_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

}
