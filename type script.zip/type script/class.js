var Sama = /** @class */ (function () {
    function Sama() {
    }
    return Sama;
}());
var s = new Sama();
s.name = "Chandra muthu V";
s.age = 21;
s.address = "Bangalore";
var str = "Name is " + s.name + "\nAge is: " + s.age + "\nAddress is " + s.address;
console.log(str);
