function add(x, y, z) {
    var result;
    if (typeof x == "number" && typeof y == "number" && typeof z == "number") {
        result = x + y + z;
    }
    else {
        result = x + y + "suryachandra" + z;
    }
    return result;
}
console.log(add(10, 20, 30));
console.log(add("ryrtyry", "dfgdfg", "gfgd"));
