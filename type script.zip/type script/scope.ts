function f1()
{
    let a=102;
    if(a>100)
    {
        var b=234;
        console.log(a);

    }
    console.log(b);
}
f1();