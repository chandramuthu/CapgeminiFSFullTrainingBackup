function add(a, b)
{
return a+b;
}
function add1(a :number,b:number)
{
return a+b;
}
function add2(a :number,b:number,c?)
{
return a+b+c;
}
var n=add(10,20);
var n1=add1(10,20);
var n2=add("hdgas",20);
var n3=add2(10,20,30);
var n4=add2(10,20);
//add1("jkj",20);
console.log(n);
console.log(n1);
console.log(n2);
console.log(n3);
console.log(n4);
function add3(a :number,b:number,c?:number)
{
return a+b+c;
}
var n5=add3(10,20,12);
console.log(n5);
//var n5=add3(10,20,"dgfg");
var d="gdfgd";
function add4(a :number,b:number,c?:number):number
{
return a+b+c;
//return a+b+c+d;
}
var n6=add3(10,20,12);
console.log(n6);