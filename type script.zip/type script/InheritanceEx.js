var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Person = /** @class */ (function () {
    function Person(firstname, lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    Person.prototype.fullname = function () {
        return this.firstname + "" + this.lastname;
    };
    return Person;
}());
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee(_id, _firstname, _lastname) {
        var _this = _super.call(this, _firstname, _lastname) || this;
        _this.id = _id;
        return _this;
    }
    Employee.prototype.showDetails = function () {
        console.log(this.id + ":" + this.fullname());
    };
    return Employee;
}(Person));
var e1 = new Employee(1, "Chandra ", "Muthu");
e1.showDetails();
