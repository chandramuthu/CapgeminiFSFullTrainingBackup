class Person{
    firstname:string;
    lastname:string;
    constructor(firstname:string,lastname:string){
    this.firstname=firstname;
    this.lastname=lastname;
    }
    fullname():string{
    return this.firstname+ ""+this.lastname;
    }
   }
   class Employee extends Person{
    id:number;
    constructor(_id:number,_firstname:string,_lastname:string){
    super(_firstname,_lastname);
    this.id=_id;
    }
    showDetails():void{
    console.log(this.id+":"+this.fullname());
    }
   }
   let e1=new Employee(1,"Chandra ","Muthu");
   e1.showDetails();