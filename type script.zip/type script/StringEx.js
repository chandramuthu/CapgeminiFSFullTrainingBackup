var firstname = "google";
var site = "www.google.com";
var str = "My name is  " + firstname + " and My site name is " + site;
console.log(str);
var str1 = "Hello,my name is " + firstname + "\nand my site is " + site;
console.log(str1);
