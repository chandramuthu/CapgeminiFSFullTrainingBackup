let num=12;
let a1=[1,3,5,8,"sum",true];
let x:number[];
x=[1,5,6,9,7,56,64,2564];
for(var i=0;i<x.length;i++)
{
    console.log(x[i]);
}
for(let i in a1)
{
    console.log(a1[i]); 
}

let numberList:number[]=[12,56,65,9,86,5,54];
for(let i in a1)
{
    console.log(numberList[i]); 
}
let numList:Array<number>=[454,54,54,5,454,4,54,4,4,454,54,45];
for(let i in a1)
{
    console.log(numList[i]); 
}