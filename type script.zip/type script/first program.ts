var a:number=123;
var b:number;
var c:boolean;
var d:string;
var e:null;
var f=undefined;
a=20;
b=30;
console.log("My first program Executed  ")
console.log(a+b);
console.log(f)