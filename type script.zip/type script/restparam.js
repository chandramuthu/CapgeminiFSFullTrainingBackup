function add(x) {
    var y = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        y[_i - 1] = arguments[_i];
    }
    var result = x;
    for (var i = 0; i < y.length; i++) {
        result += y[i];
    }
    return result;
}
console.log(add(10, 20, 30, 40, 56, 52, 20));
console.log(add(10, 20, 30, 20, 30, 40, 56, 40, 56, 52, 20));
