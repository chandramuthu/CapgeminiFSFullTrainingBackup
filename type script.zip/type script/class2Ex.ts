class Employee
{
    static empid:number;
name:string;
constructor(empid:number,name:string)
{
    Employee.empid=empid;
    this.name=name;
    
}
displayDetails()
{
    return Employee.empid+" : "+this.name;
}

Employee.empid=1234;


}