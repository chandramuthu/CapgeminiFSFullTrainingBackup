function add(x:number,...y:number[])
{
    let result=x;
    for(var i=0;i<y.length;i++)
    {
        result+=y[i];
    }
return result;
}
console.log(add(10,20,30,40,56,52,20));
console.log(add(10,20,30,20,30,40,56,40,56,52,20));