function add(x:number,y:number,z:number):number;
function add(x:string,y:string,z:string):string;
function add(x:any,y:any,z:any)
{
    let result:any;
if(typeof x=="number" && typeof y=="number" && typeof z=="number" )
{
    result=x+y+z;
}
else 
{
    result=x+y+"suryachandra"+z;
}
return result;
}
console.log(add(10,20,30));
console.log(add("ryrtyry","dfgdfg","gfgd"));
