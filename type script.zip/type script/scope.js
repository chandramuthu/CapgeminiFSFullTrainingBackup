function f1() {
    var a = 102;
    if (a > 100) {
        var b = 234;
        console.log(a);
    }
    console.log(b);
}
f1();
