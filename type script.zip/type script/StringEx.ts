let firstname :string="google";
let site:string="www.google.com";
let str="My name is  "+firstname+" and My site name is "+site;
console.log(str);

let str1=`Hello,my name is ${firstname}
and my site is ${site}`
console.log(str1);