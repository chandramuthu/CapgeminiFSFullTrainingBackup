
let sum1=(x:number,y:number)=>x+y;
var n=sum1(10,20);
console.log(n);