var num = 12;
var a1 = [1, 3, 5, 8, "sum", true];
var x;
x = [1, 5, 6, 9, 7, 56, 64, 2564];
for (var i = 0; i < x.length; i++) {
    console.log(x[i]);
}
for (var i_1 in a1) {
    console.log(a1[i_1]);
}
var numberList = [12, 56, 65, 9, 86, 5, 54];
for (var i_2 in a1) {
    console.log(numberList[i_2]);
}
var numList = [454, 54, 54, 5, 454, 4, 54, 4, 4, 454, 54, 45];
for (var i_3 in a1) {
    console.log(numList[i_3]);
}
