var sum1 = function (x, y) { return x + y; };
var n = sum1(10, 20);
console.log(n);
