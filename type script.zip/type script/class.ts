class Sama
{
    name:string;
    age:number;
    address:string;
}
var s=new Sama();
s.name="Chandra muthu V";
s.age=21;
s.address="Bangalore";
var str=`Name is ${s.name}
Age is: ${s.age}
Address is ${s.address}`
console.log(str);