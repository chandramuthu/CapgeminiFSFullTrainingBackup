

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="cust")
public class Customers {
    @Id
    @Column(length=20)
    private int CustomerId;
    private String CustomerName;
    public int getCustomerId() {
        return CustomerId;
    }
    public void setCustomerId(int customerId) {
        CustomerId = customerId;
    }
    public String getCustomerName() {
        return CustomerName;
    }
    public void setCustomerName(String customerName) {
        CustomerName = customerName;
    }
    public Customers(int customerId, String customerName) {
        super();
        CustomerId = customerId;
        CustomerName = customerName;
    }
    
    
    public Customers() {
        // TODO Auto-generated constructor stub
    }
    }
 




