

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class TestOneToMany {
  public static void main(String[] args) {
     
            EntityManagerFactory emf=Persistence.createEntityManagerFactory("a");
            EntityManager entityManager=emf.createEntityManager();
            entityManager.getTransaction().begin();
            
            
      Vendor v=new Vendor();
      v.setVendorId(100);
      v.setVendorName("Ibaco");
      
      
      Customers c=new Customers(1, "IBM");
      Customers c1=new Customers(2, "Google");
      Customers c2=new Customers(3, "Capgemini");
      Set s=new HashSet();
      s.add(c);
      s.add(c1);
      s.add(c2);
      v.setChildren(s);
      entityManager.persist(v);
      
      
    }}




