

import java.util.Set;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@Entity
public class Vendor {
    @Id
    @Column(name = "vid", length=20)
    private int vendorId;public Vendor() {
		// TODO Auto-generated constructor stub
	}
    @Column(name = "vname", length=20)
    private String vendorName;
    public Vendor(int vendorId, String vendorName, Set children) {
		super();
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.children = children;
	}
	@OneToMany(targetEntity=Customers.class)
    @JoinColumn(name = "venId",referencedColumnName="vid")
    
    private Set children;
    public int getVendorId() {
        return vendorId;
    }
    public void setVendorId(int vendorId) {
        this.vendorId = vendorId;
    }


    public String getVendorName() {
        return vendorName;
    }
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }
    public Set getChildren() {
        return children;
    }
    public void setChildren(Set children) {
        this.children = children;
    }
    
}
 






