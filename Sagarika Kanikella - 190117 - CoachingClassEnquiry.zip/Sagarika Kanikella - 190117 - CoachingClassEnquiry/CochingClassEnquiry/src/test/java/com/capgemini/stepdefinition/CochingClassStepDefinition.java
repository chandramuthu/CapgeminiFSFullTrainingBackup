package com.capgemini.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.pom.CoachingClassPageFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CochingClassStepDefinition {

	private WebDriver driver;
	private CoachingClassPageFactory pageFactory;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");

		driver = new ChromeDriver();
	}

	@Given("^User is navigated to 'Coaching Class Enquiry' page$")
	public void user_is_navigated_to_Coaching_Class_Enquiry_page() throws Throwable {

		 Thread.sleep(15000);
		driver.get("C:\\BDD1\\CochingClassEnquiry\\html\\Coaching_Class_Enquiry.html");
		pageFactory = new CoachingClassPageFactory(driver);
	}

	@When("^page is loaded$")
	public void page_is_loaded() throws Throwable {

	}

	@Then("^Checks if the title of the page is 'Online Coaching Class Enquiry Form'$")
	public void checks_if_the_title_of_the_page_is_Online_Coaching_Class_Enquiry_Form() throws Throwable {

		String expectedTitle = "Online Coaching Class Enquiry Form";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Then("^Check if there is a text 'Tuition Enquiry Details Form'$")
	public void check_if_there_is_a_text_Tuition_Enquiry_Details_Form() throws Throwable {

		boolean expectedResult = true;
		String expectedText = "Tuition Enquiry Details Form";
		boolean actualResult = driver.getPageSource().contains(expectedText);
		Assert.assertEquals(expectedResult, actualResult);
		driver.close();
	}

	@When("^User enters no data in first name$")
	public void user_enters_no_data_in_first_name() throws Throwable {

		pageFactory.setFirstName("");
		pageFactory.setSubmitButton();
	}

	@Then("^The alert box displays 'First Name must be filled out'$")
	public void the_alert_box_displays_First_Name_must_be_filled_out() throws Throwable {

		String expectedText = "First Name must be filled out";
		String actualText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, actualText);
		driver.close();
	}

	@When("^User enters no data in last name$")
	public void user_enters_no_data_in_last_name() throws Throwable {

		pageFactory.setLastName("");
		pageFactory.setSubmitButton();
	}

	@Then("^The alert box displays 'Last Name must be filled out'$")
	public void the_alert_box_displays_Last_Name_must_be_filled_out() throws Throwable {

		String expectedText = "Last Name must be filled out";
		String actualText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, actualText);
		driver.close();
	}

	@Given("^user is navigated to 'Coaching Class Enquiry' page$")
	public void user_is_navigated_to_Coaching_Class_Enquiry_page1() throws Throwable {
		
		driver.get("C:\\BDD1\\CochingClassEnquiry\\html\\Coaching_Class_Enquiry.html");
		pageFactory = new CoachingClassPageFactory(driver);
	}

	@When("^User enters email$")
	public void user_enters_email() throws Throwable {

		pageFactory.setEmail("sagarika@gmail.com");
	}

	@When("^Data is entered in the Mobile text box$")
	public void data_is_entered_in_the_Mobile_text_box() throws Throwable {

		pageFactory.setMobile("saga");
		pageFactory.setSubmitButton();
	}

	@Then("^The alert box displays 'Enter numeric value'$")
	public void the_alert_box_displays_Enter_numeric_value() throws Throwable {

		String expectedText = "Enter numeric value";
		String actualText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, actualText);
		driver.close();
	}

	@When("^User enters invalid data in the Mobile text box$")
	public void user_enters_invalid_data_in_the_Mobile_text_box() throws Throwable {
		pageFactory.setMobile("807548");
		pageFactory.setSubmitButton();
	}

	@Then("^The alert box displays 'Enter (\\d+) digit Mobile number'$")
	public void the_alert_box_displays_Enter_digit_Mobile_number(int arg1) throws Throwable {

		String expectedText = "Enter 10 digit Mobile number";
		String actualText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, actualText);
		driver.close();
	}

	@When("^User selects type of tuition as 'Spoken English'$")
	public void user_selects_type_of_tuition_as_Spoken_English() throws Throwable {
		pageFactory.setTuition("Spoken English");
	}

	@When("^User selects city preference as 'Pune'$")
	public void user_selects_city_preference_as_Pune() throws Throwable {
		pageFactory.setCity("Pune");
	}

	@When("^Select Mode of the learning as 'Class room training'$")
	public void select_Mode_of_the_learning_as_Class_room_training() throws Throwable {
		pageFactory.setMode("Class rooom training");
	}

	@When("^User submit the request button$")
	public void user_submit_the_request_button() throws Throwable {
		pageFactory.setSubmitButton();
	}

	@Then("^User verify that alert box displays 'Enquiry details must be filled out'$")
	public void user_verify_that_alert_box_displays_Enquiry_details_must_be_filled_out() throws Throwable {

		String expectedText = "Enquiry details must be filled out";
		String actualText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, actualText);
		driver.close();
	}

	@When("^User enters valid enquiry details$")
	public void user_enters_valid_enquiry_details() throws Throwable {
		pageFactory.setFirstName("Sagarika");
		pageFactory.setLastName("Kanikella");
		pageFactory.setEmail("sagarika@example.com");
		pageFactory.setMobile("8074355984");
		pageFactory.setTuition("Spoken English");
		pageFactory.setCity("Pune");
		pageFactory.setMode("Class rooom training");
		pageFactory.setEnquiry("This is an enquiry text");
		pageFactory.setSubmitButton();
	}

	@Then("^Verify the message 'Thank you for submitting the online coaching Class Enquiry'$")
	public void verify_the_message_Thank_you_for_submitting_the_online_coaching_Class_Enquiry() throws Throwable {

		String expectedText = "Thank you for submitting the online coaching Class Enquiry";
		String actualText = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedText, actualText);
	}

	@Then("^Click OK$")
	public void click_OK() throws Throwable {

		driver.switchTo().alert().accept();
	}

	@Then("^User verify the text 'Our Counselor will contact you soon' after submission of form$")
	public void user_verify_the_text_Our_Counselor_will_contact_you_soon_after_submission_of_form() throws Throwable {

		String expectedText = "Our Counselor will contact you soon.";
		String actualText = driver.findElement(By.tagName("h3")).getText();
		Assert.assertEquals(expectedText, actualText);
	}

	@Then("^Close the browser window$")
	public void close_the_browser_window() throws Throwable {
		driver.quit();
	}

}
