package com.capgemini.stepdefinition;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "feature/coachingClassEnquiry.feature", glue = "com.capgemini.stepdefinition")
public class CoachingTest {

	public static void main(String[] args) {

	}

}
