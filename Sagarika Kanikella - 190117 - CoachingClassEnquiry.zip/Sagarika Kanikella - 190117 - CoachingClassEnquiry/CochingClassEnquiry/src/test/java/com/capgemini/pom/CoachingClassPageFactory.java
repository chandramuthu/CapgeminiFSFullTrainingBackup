package com.capgemini.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CoachingClassPageFactory {

	WebDriver driver;

	@FindBy(name = "fname")
	@CacheLookup
	WebElement firstName;

	@FindBy(xpath = "//*[@name='lname']")
	@CacheLookup
	WebElement lastName;

	@FindBy(how = How.ID, using = "emails")
	@CacheLookup
	WebElement email;

	@FindBy(name = "mobile")
	@CacheLookup
	WebElement mobile;

	@FindBy(name = "D6")
	@CacheLookup
	WebElement tution;

	@FindBy(name = "D5")
	@CacheLookup
	WebElement city;

	@FindBy(name = "D4")
	@CacheLookup
	WebElement mode;

	@FindBy(how = How.ID, using = "enqdetails")
	@CacheLookup
	WebElement enquiry;

	@FindBy(how = How.ID, using = "Submit1")
	@CacheLookup
	WebElement submitButton;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(WebElement firstName) {
		this.firstName = firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(WebElement lastName) {
		this.lastName = lastName;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(WebElement mobile) {
		this.mobile = mobile;
	}

	public WebElement getTution() {
		return tution;
	}

	public void setTution(WebElement tution) {
		this.tution = tution;
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(WebElement city) {
		this.city = city;
	}

	public WebElement getMode() {
		return mode;
	}

	public void setMode(WebElement mode) {
		this.mode = mode;
	}

	public WebElement getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(WebElement enquiry) {
		this.enquiry = enquiry;
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton(WebElement submitButton) {
		this.submitButton = submitButton;
	}

	// initiating the elements
	public CoachingClassPageFactory(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void setFirstName(String firstName) {

		this.firstName.sendKeys(firstName);

	}

	public void setSubmitButton() {
		this.submitButton.click();
	}

	public void setLastName(String lastName) {

		this.lastName.sendKeys(lastName);

	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public void setTuition(String tution) {
		this.tution.sendKeys(tution);

	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public void setMode(String mode) {
		this.mode.sendKeys(mode);
	}

	public void setEnquiry(String enquiry) {
		this.enquiry.sendKeys(enquiry);
	}

}
